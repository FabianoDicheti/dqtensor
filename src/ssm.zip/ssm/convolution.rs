/// Gera o kernel causal de convolução K para um SSM diagonal
pub fn generate_kernel(
    A: &Vec<f64>,
    B: &Vec<f64>,
    C: &Vec<f64>,
    length: usize
) -> Vec<f64> {
    let d = A.len();
    let mut kernel = vec![0.0; length];

    for k in 0..length {
        let mut sum = 0.0;
        for i in 0..d {
            let Ak = A[i].powi(k as i32);  // A^k
            sum += C[i] * Ak * B[i];       // K_k[i]
        }
        kernel[k] = sum;
    }

    kernel
}
